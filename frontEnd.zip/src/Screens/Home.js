import React from "react";
import { View ,Text} from "react-native";





function HomeScreen(){
    return <View><Text>Anasayfa</Text></View>
}


export default HomeScreen;