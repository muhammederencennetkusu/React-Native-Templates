import React from "react";
import { View,Text } from "react-native";





function Settings(){
    return <View><Text>Ayarlar</Text></View>
}


export default Settings;